<?php
// 			FROM  `tblusers` WHERE TYPE != 'Customer'");
	$mydb->setQuery("SELECT * 
					FROM  `tblblogs`");
	$cur = $mydb->loadResultList();

foreach ($cur as $result) { ?>

<div class="row">
	<div class="col-lg-12">
		<div class="page-header"><h2><a href="index.php?page=blog&id=<?php echo $result->BlogID;?>"><?php echo $result->BlogTitle;?></a></h2></div>
		<div class="body">
			<?php echo $result->Blogs;?>
		</div>
	</div>
</div> 

<?php } ?>