 
<?php 
    $BLOGID = isset($_GET['id']) ? $_GET['id'] :"";
    if ($BLOGID=="") {
      # code...
      redirect("index.php");
    }

  

    $sql = "SELECT * FROM `tblblogs` WHERE BlogID='{$BLOGID}'";
    $mydb->setQuery($sql);
    $blog = $mydb->loadSingleResult();
?>

<section id="title-header">
  <div class="page-header"> 
      <h2><?php echo substr(strtoupper($blog->BlogTitle), 0,1). substr(strtolower($blog->BlogTitle),1);?></h2>
  </div>
</section>

<div class="container">
<div class="col-lg-12">
  <p class="blog-body"><?php echo $blog->Blogs;?></p>
</div> 
<div class="col-lg-12">
  <!-- <p class="blog-body">on <?php echo $blog->BLOG_WHEN .' at '.$blog->BLOG_WHERE;?></p> -->
</div>
<div class="col-lg-12">
  <p><span class="fa fa-user"></span> By : <?php echo $blog->Author .' , Date Posted :'.date_format(date_create($blog->DatePosted),"M d, Y");?></p>
</div>
 
