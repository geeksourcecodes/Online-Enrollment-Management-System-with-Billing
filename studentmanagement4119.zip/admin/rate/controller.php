<?php
require_once ("../../include/initialize.php");
	 if (!isset($_SESSION['ACCOUNT_ID'])){
      redirect(web_root."admin/index.php");
     }

$action = (isset($_GET['action']) && $_GET['action'] != '') ? $_GET['action'] : '';

switch ($action) {
	case 'add' :
	doInsert();
	break;
	
	case 'edit' :
	doEdit();
	break;
	
	case 'delete' :
	doDelete();
	break;

	case 'photos' :
	doupdateimage();
	break;

 
	}
   
	function doInsert(){
		if(isset($_POST['save'])){
			
  		if ($_POST['Rate_Desc'] == "" OR $_POST['Amount'] == "" OR $_POST['COURSE_ID'] == "" ) {
			$messageStats = false;
			message("All field is required!","error");
			redirect('index.php?view=add');
		}else{	
			$rate = New Rates(); 
			$rate->Rate_Desc 		= $_POST['Rate_Desc'];
			$rate->Amount			= $_POST['Amount'];
			$rate->COURSE_ID		= $_POST['COURSE_ID']; 
			$rate->create();

						// $autonum = New Autonumber(); 
						// $autonum->auto_update(2);

			message("New [". $_POST['Rate_Desc'] ."] created successfully!", "success");
			redirect("index.php");
			
		}
		}

	}

	function doEdit(){
	if(isset($_POST['save'])){

			$rate = New Rates(); 
			$rate->Rate_Desc 		= $_POST['Rate_Desc'];
			$rate->Amount		= $_POST['Amount'];
			$rate->COURSE_ID		= $_POST['COURSE_ID']; 
			$rate->update($_POST['RateID']);

			  message("[". $_POST['Rate_Desc'] ."] has been updated!", "success");
			redirect("index.php");
		}
	}


	function doDelete(){
		
		// if (isset($_POST['selector'])==''){
		// message("Select the records first before you delete!","info");
		// redirect('index.php');
		// }else{

		// $id = $_POST['selector'];
		// $key = count($id);

		// for($i=0;$i<$key;$i++){

		// 	$course = New User();
		// 	$course->delete($id[$i]);

		
				$id = 	$_GET['id'];

				$rate = New Rates();
	 		 	$rate->delete($id);
			 
			message("Course already Deleted!","info");
			redirect('index.php');
		// }
		// }

		
	}

	 
?>