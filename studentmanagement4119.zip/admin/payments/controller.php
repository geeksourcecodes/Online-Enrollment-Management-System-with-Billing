<?php
require_once ("../../include/initialize.php");
	 if (!isset($_SESSION['ACCOUNT_ID'])){
      redirect(web_root."admin/index.php");
     }

$action = (isset($_GET['action']) && $_GET['action'] != '') ? $_GET['action'] : '';

switch ($action) {
	case 'add' :
	doInsert();
	break;
	
	case 'edit' :
	doEdit();
	break;
	
	case 'delete' :
	doDelete();
	break;

	case 'photos' :
	doupdateimage();
	break;

 
	}
   
	function doInsert(){
		global $mydb;
		if(isset($_POST['save'])){

			$sql = "INSERT INTO `tbltransaction` (`IDNO`, `COURSE_ID`, `TotalAmount`, `AmountPaid`, `Balance`, `TransDate`) 
			VALUES ('".$_POST['IDNO']."',".$_POST['COURSE_ID'].",'".$_POST['totalamount']."','".$_POST['tenderamount']."','".$_POST['sukli']."',Now())";
			$mydb->setQuery($sql); 
			$mydb->executeQuery();

 			 message("Payment has been saved", "success");
			redirect("index.php?view=POS&id=".$_POST['IDNO']);
		}

	}

	function doEdit(){
	if(isset($_POST['save'])){ 

 		$desc = $_POST['DESCRIPTION'];

			$dept = New Department(); 
			$dept->DEPARTMENT_NAME 		= $_POST['DEPARTMENT_NAME'];
			$dept->DEPARTMENT_DESC		= $desc;  
			$res = $dept->update($_POST['DEPT_ID']);

			  message("[". $_POST['DEPARTMENT_NAME'] ."] has been updated!", "success");
			redirect("index.php");
			 
			
		}
	}


	function doDelete(){
		
	 
				$id = 	$_GET['id'];

				$dept = New Department();
	 		 	$dept->delete($id);
			 
			message("Department already Deleted!","info");
			redirect('index.php');
		 
		
	}

	 
 
?>