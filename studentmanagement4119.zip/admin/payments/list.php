<?php
	 if (!isset($_SESSION['ACCOUNT_ID'])){
      redirect(web_root."admin/index.php");
     }

?>

 
	 <style type="text/css">
 .scrolly {
   /*width: auto;*/
    height:268px;
    /*border: thin solid black;*/
    overflow-x: hidden; 
    background-color: #eee;
    /*overflow-y: hidden;*/
} 
 .scrollorder {
   /*width: auto;*/
    height:450px;
    /*border: thin solid black;*/
    overflow-x: hidden; 
    /*overflow-y: hidden;*/
    padding: 0px;
} 
.header{
    font-size: 25px;
    font-weight: bold;
    margin-left: 0;
    padding: 5px;
}

.form-control{
    width: 59%;
}

input[type="checkbox"]{
    width: 30px;
    height: 30px;
    margin-left: 80px;
}

 </style>
<form class="form" action="controller.php?action=add" method="POST" > 
<!-- orders -->
    <div class="col-lg-5">
    	<div class="col-lg-12">
    		<div class="row">
    			<div class="header" >
    				List of Students</div> 
                    <div class="row">
                    <div style="padding: 5px 15px;float: right;" >Search : <input type="text" name="myInput" id="myInput" onkeyup="SearchTable() " placeholder="Search for ID"></div>
                        
                    </div>
                    <div id="reload" class="scrollorder">

                        <table id="dashtable" class="table table-striped table-bordered table-hover table-responsive" style="font-size:12px" cellspacing="0">
				
				  <thead>
				  	<tr>
				  		<th>ID</th>
				  		<th> 
				  		 Name</th> 
				  		<th>Course</th> 
				 
				  	</tr>	
				  </thead> 
				  <tbody> 

				  	<?php  
				  	 	$sql ="SELECT * FROM `tblstudent` s,course c WHERE s.COURSE_ID=c.COURSE_ID AND  NewEnrollees=0";  
			  			$mydb->setQuery($sql);

				  		$cur = $mydb->loadResultList();

						foreach ($cur as $result) {
							
							if($result->BDAY!='0000-00-00'){
								$age = date_diff(date_create($result->BDAY),date_create('today'))->y;
							}else{
								$age='None';
							}
				  		echo '<tr>';
				  		// echo '<td width="5%" align="center"></td>';
				  		echo '<td><a  href="index.php?view=POS&id='.$result->IDNO.'" >' . $result->IDNO.'</a></td>';
				  		echo '<td>'. $result->LNAME.','. $result->FNAME.' '. $result->MNAME.'</td>'; 
				  		echo '<td>' . $result->COURSE_NAME.'-' . $result->COURSE_LEVEL.'</a></td>'; 
				  		echo '</tr>';
				  	} 
				  	?>
				  </tbody>
					
				</table>
                </div>
            </div> 
    	</div> 
    </div>
<!-- end orders -->
 	<!-- SUMARRY -->
 	<div class="col-lg-7" style="border-left: 1px solid #ddd;">
    	<div class="col-lg-12">
    	<!-- order details -->
    		<div class="row">
    			<div   style="font-size: 24px;font-weight: bold;margin-top: 10px;">
    				Payments History  
    			</div>
    			<table>
    				<?php 
    				if (isset($_GET['id'])) {
    					# code...
    					$sql ="SELECT * FROM `tblstudent` s,course c WHERE s.COURSE_ID=c.COURSE_ID AND IDNO=". $_GET['id'];  
						$mydb->setQuery($sql);
						$fullname = $mydb->loadSingleResult();
    					
			  		?>
    				<tr style="font-weight: bold;">
    					<td width="50%">IDNO : <?php echo $_GET['id'];?></td>	<td>Name: <?php echo  $fullname->LNAME.','. $fullname->FNAME.' '. $fullname->MNAME;?></td>
    				</tr>
    			<?php } ?>
    			</table>
                <div id="showmeal">
    			<div class="scrolly">
    			<table id="table" class="table table-hover" style="font-size: 12px" >
    				<thead>
    					<tr style="font-size: 15px;"> 
    					    <th>Date</th>
							<th>Amount Paid</th> 
							<th>Balance</th> 
    					</tr> 
    				</thead>
    				<tbody>
    					<?php 
    					$total = 0;
    						if (isset($_GET['id'])) {
    							# code...
    							$IDNO = $_GET['id'];
    							$query = "SELECT * FROM `tbltransaction` WHERE  `IDNO`='".$IDNO."'";
						  		$mydb->setQuery($query);
						  		$cur = $mydb->loadResultList();

								foreach ($cur as $result) { 
						  		echo '<tr>'; 
						  		echo '<td style="font-size:15px;">'.$result->TransDate.'</td>';
						  		echo '<td style="font-size:15px;">&#8369; '.$result->AmountPaid.'</td>';
						  		echo '<td style="font-size:15px;">&#8369; '.$result->Balance.'</td>'; 
						  		echo '</tr>';

						  		// $total += $result->SUBTOTAL; 

						  	 
						  		} 
    						}
					  		
				  		?> 
				  		<!-- <tr>
				  			<td colspan="4"></td>
				  		</tr> -->
    				</tbody>
    			</table>
    				
    			</div> 
    		<!-- <hr/> -->
    		<!-- end order details -->
    		<!-- summary --> 
    			<div style="font-size: 19px;font-weight: bold;margin-top:20px;margin-bottom: 3px">
    				Summary
    			</div>
                <?php 
                $sql = "SELECT * FROM `tbltransaction` WHERE `IDNO`='".@$IDNO."' ORDER BY TransID DESC LIMIT 1";
                $mydb->setQuery($sql);
                $bal = $mydb->loadSingleResult();
                 ?>
    			<table class="table table-bordered">
    				<thead>
    					<tr>
    						<th width="250">Balance</th>
    						<th><input class="form-control" type="text" id="totamnt"  readonly="true" value="<?php echo number_format(isset($bal->Balance) ? $bal->Balance : 0,2); ?>">
    						<input type="hidden" name="totalamount" id="totalamount"   value="<?php echo $bal->Balance; ?>">
    					<input type="hidden" name="IDNO"   value="<?php echo $bal->IDNO; ?>">
    				<input type="hidden" name="COURSE_ID"    value="<?php echo $bal->COURSE_ID; ?>"></th>
    					</tr> 
                       <!--  <tr>
                            <th width="250">Total</th>
                            <th><input class="form-control" type="text" id="overalltot"  readonly="true" value="<?php echo number_format($total,2); ?>">
                            <input type="hidden" name="overalltotal" id="overalltotal"   value="<?php echo number_format($total,2); ?>"></th>
                        </tr> -->
    					<tr>
    						<th width="250">Tender Amount</th>
    						<th><input type="text" class="form-control"  name="tenderamount" id="tenderamount"  placeholder="&#8369 0.00" autocomplete="off"  > <span id="errortrap"></span></th>
    					</tr>
    					<tr>
    						<th width="250">Remaining Balance</th>
    						<th><input class="form-control" type="" class="sukli" readonly="true" name="sukli" id="sukli" value="" placeholder="&#8369 0.00"></th>
    					</tr>
    				</thead>
    			</table>
    			<div>
    				<button  type="submit" name="save" class="btn btn-primary btn-lg fa fa-save" id="save"> Save </button> 
    			</div>
    		</div> 
    		<!-- end summary -->
     	</div> 
    </div>
    </form>

  <script>
function SearchTable() {
  // Declare variables 
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("dashtable");
  tr = table.getElementsByTagName("tr");
  td = table.getElementsByTagName("td");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    } 
  }
}



</script>

<br/>
<br/>
<br/>
<br/>