<table id="table" class="table table-hover" style="font-size: 12px" >
    				<thead>
    					<tr style="font-size: 15px;"> 
    					    <th>Date</th>
							<th>Amount Paid</th> 
							<th>Balance</th> 
    					</tr> 
    				</thead>
    				<tbody>
    					<?php 
    					$total = 0; 
    							# code...
    							$IDNO = $_SESSION['IDNO'];
    							$query = "SELECT * FROM `tbltransaction` WHERE  `IDNO`='".$IDNO."'";
						  		$mydb->setQuery($query);
						  		$cur = $mydb->loadResultList();

								foreach ($cur as $result) { 
						  		echo '<tr>'; 
						  		echo '<td style="font-size:15px;">'.$result->TransDate.'</td>';
						  		echo '<td style="font-size:15px;">&#8369; '.$result->AmountPaid.'</td>';
						  		echo '<td style="font-size:15px;">&#8369; '.$result->Balance.'</td>'; 
						  		echo '</tr>';

						  		// $total += $result->SUBTOTAL; 

						  	 
						  		}  
					  		
				  		?> 
				  		<!-- <tr>
				  			<td colspan="4"></td>
				  		</tr> -->
    				</tbody>
    			</table>