<style type="text/css">
#myCarousel{
  margin-top: -48px;
}
#crsel {
  height:350px;
 }
  .fills img {
    width: 100%; 
    height: 350px;
  }
</style>
 
     <header id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
            <li data-target="#myCarousel" data-slide-to="3"></li>
            <li data-target="#myCarousel" data-slide-to="4"></li>
            <li data-target="#myCarousel" data-slide-to="5"></li>
            <!-- <li data-target="#myCarousel" data-slide-to="6"></li> -->
        </ol>

 
  
        <div id="crsel" class="carousel-inner">

            <div class="item active">
            <div class="fills">  
                    <img src="<?php echo web_root ;?>img/bgAdmin.jpg" > 
              </div>
                <div class="carousel-caption">
                    <!-- <h2>K12 Now Ready</h2> -->
                </div>
            </div>
            <div class="item ">
            <div class="fills">  
                    <img src="<?php echo web_root ;?>img/slide1.jpg"   /> 
              </div>
                <div class="carousel-caption">
                    <!-- <h2>K12 Now Ready</h2> -->
                </div>
            </div>
            <div class="item">
            <div class="fills">  
                    <img src="<?php echo web_root ;?>img/slide2.png"   /> 
              </div>
                <div class="carousel-caption">
                    <!-- <h2>K12 Now Ready</h2> -->
                </div>
            </div>
      <!--       <div class="item">
            <div class="fills">  
                    <img src="<?php echo web_root ;?>img/slide3.jpg"   /> 
              </div>
                <div class="carousel-caption"> 
                </div>
            </div>
 -->
            <div class="item">
            <div class="fills">  
                    <img src="<?php echo web_root ;?>img/slide4.jpg"   /> 
              </div>
                <div class="carousel-caption">
                    <!-- <h2>K12 Now Ready</h2> -->
                </div>
            </div> 
            <div class="item">
            <div class="fills">  
                    <img src="<?php echo web_root ;?>img/slide6.png"   /> 
              </div>
                <div class="carousel-caption">
                    <!-- <h2>K12 Now Ready</h2> -->
                </div>
            </div>
            <div class="item">
            <div class="fills">  
                    <img src="<?php echo web_root ;?>img/slide7.jpg"   /> 
              </div>
                <div class="carousel-caption">
                    <!-- <h2>K12 Now Ready</h2> -->
                </div>
            </div>
           
        </div>

         <!-- Controls -->
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="icon-prev"></span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="icon-next"></span>
        </a>

</header>
 